document.write("<hr>");
document.write("Hello World Wide Web");
document.write("<hr>");