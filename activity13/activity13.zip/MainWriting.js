document.write("<hr>");
document.write("Hello World Wide Web");
document.write("<hr>");

function makeRecipe() {
    var recipe = {
     title: "sugar cookie",
     servings: "4",
     ingredients: ["sugar", "flour", "eggs", "milk"]
     }
     document.write("name " + recipe.title);
     document.write("<br>");
     document.write("serves: " + recipe.servings);
     document.write("<br>");
     document.write("ingredients: " + recipe.ingredients);
     document.write("<br>");
    }

makeRecipe();

var books = [{title: "Thinking with Type", author: "Ellen Lupton", alreadyRead: true}, 
    {title: "The Design of Everyday Things", author: "Don Norman", alreadyRead: false}, 
    {title: "Don't Make Me Think", author: "Steve Krug", alreadyRead: true}, 
    {title: "Making and Breaking the Grid", author: "Timothy Samara", alreadyRead: true}]

for(var j = 0; j < books.length; j++){
    document.write(books[j].title + " by " + books[j].author);
    document.write("<br>");
    }

for(var i = 0; i < books.length; i++){
    if(books[i].alreadyRead == true){
        document.write("You have already read " + books[i].title + " by " + books[i].author);
        document.write("<br>");
    }
    else{
        document.write("You still need to read " + books[i].title + " by " + books[i].author);
        document.write("<br>");
    }
}